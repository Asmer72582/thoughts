$(document).ready( function() {

    $('#myform').on('submit', function(event) {
      
    	$.ajax({
                type: "POST",
                url: "manage.php",
                data: $(this).serialize(),
                success: function(responce){
                	if (jQuery.trim(responce) == 'ok') {
                        toastr.error('error',{timeout:2000});

                    $('#myform').trigger('reset');
                	}
                	else{
                		toastr.error('error',{timeout:2000});
                	}
                },
                error: function() {
                  toastr.error('error',{timeout:2000});

                }
                   
            });

      return false;
    });

    
    
  });
